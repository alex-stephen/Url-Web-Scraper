How to use the program.

1. External Libraries used: (pip install "package") in .../Scripts
    - bs4 (beautifulsoup4)
    - requests

   Alternatively type python3 -m pip install -U -r requirements.txt --user && python3 main.py

2. Change the Homepage you wish to begin from by changing the value of "homepage"

3. Change the value of target set to the webpage you wish to find labeled "target"

4. Run the program and wait